# Backend

## Start the application:
Run below scripts
```
npm run tsc
npm run start
```


